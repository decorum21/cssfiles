<?

$to = "https://outlook.office.com/mail/inbox";

?>